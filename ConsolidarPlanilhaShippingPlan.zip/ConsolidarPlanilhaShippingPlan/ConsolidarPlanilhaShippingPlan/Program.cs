﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace ConsolidarPlanilhaShippingPlan
{
    class Program
    {
        static void Main(string[] args)
        {
            DirectoryInfo excelDirectory = new DirectoryInfo(@"H:\Publico\CSD IT - Projetos\20160820 - AGOSTO");
            FileInfo[] excelFiles = excelDirectory.GetFiles("0*");
            foreach (var item in excelFiles)
            {
                Console.WriteLine(item.ToString());
            }
            string workbookPathRede = excelDirectory + @"\" + excelFiles[3].ToString();
            Excel.Application excelApp = new Excel.Application();
            excelApp.Visible = true;

            string workbookPath = workbookPathRede;
            var workbooks = excelApp.Workbooks;
            Excel.Workbook excelWorkbook = workbooks.Open(workbookPath,
                    false, true, 5, "", "", false, Excel.XlPlatform.xlWindows, "",
                    true, false, 0, true, false, false);
            excelWorkbook.Application.DisplayAlerts = false;
            Excel.Sheets excelSheets = excelWorkbook.Worksheets;
            Excel.Worksheet Worksheet = (Excel.Worksheet)excelSheets.get_Item(1);

   
            Excel.Workbook xlWorkBook;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = excelApp.Workbooks.Add(misValue);
            Excel.Sheets excelSheetsDestino = xlWorkBook.Worksheets;
            Excel.Worksheet WorksheetConsolidado = (Excel.Worksheet)excelSheetsDestino.get_Item(1);
            
            int linhaPO = 1;
            while (Worksheet.Cells[linhaPO,1].Value != "PO")
            {
                linhaPO++;
            }
            linhaPO++;
            //Console.WriteLine(Worksheet.Cells[linhaPO, 1].Text);
            int countnull = linhaPO;
            while (Worksheet.Cells[countnull, 6].Value != null)
            {
                countnull++;
            }
            countnull--;

            DateTime data1 = new DateTime(2016, 08, 1);
            DateTime data2 = new DateTime(2016, 08, 19);

            int countTermino = linhaPO;
            int linhaDestiny = 1;
            while (countnull != countTermino)
            {
                try
                {
                    string datas = Worksheet.Range["AG" + countTermino].Value.ToString();
                    datas = datas.Substring(0, 10);
                    DateTime data = DateTime.Parse(datas);
                    if (data>=data1 && data<= data2)
                    {

                        Console.WriteLine(data);
                        Excel.Range from = Worksheet.Range["A"+countTermino+":AG"+countTermino];
                        Excel.Range to = WorksheetConsolidado.Range["A"+linhaDestiny + ":AG" + linhaDestiny];
                        linhaDestiny++;
                        from.Copy(Type.Missing);
                        to.PasteSpecial(Excel.XlPasteType.xlPasteValuesAndNumberFormats, Excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
                    }
                }
                catch (Exception err)
                {

                }
                countTermino++;
            }
            /*Console.Read();
            Excel.Range from = Worksheet.Range["A"+linhaPO+ ":AG" + countnull];
            Excel.Range to = WorksheetConsolidado.Range["A1:AG" +countnull];
            from.Copy(Type.Missing);
            to.PasteSpecial(Excel.XlPasteType.xlPasteValuesAndNumberFormats, Excel.XlPasteSpecialOperation.xlPasteSpecialOperationNone, false, false);
            */
            Console.Read();
            if (Worksheet.Cells[linhaPO,33].Value.IndexOf("ETD")== -1)
            {
                Console.WriteLine("oi");

            }
            else
            {
                Console.WriteLine("tchau");
            }
            
            try
            {
                Worksheet.Range["AK:AK"].Insert(Excel.XlInsertShiftDirection.xlShiftToRight);
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
                
            }
            
            
        }
    }
}
