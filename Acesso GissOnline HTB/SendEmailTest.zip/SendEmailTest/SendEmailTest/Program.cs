﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;

namespace SendEmailTest
{
    class Program
    {
        static void Main(string[] args)
        {
            string smtpAddress = "smtp.gmail.com";
            int portNumber = 587;
            bool enableSSL = true;

            string emailFrom = "miguelkedroon@gmail.com";
            string password = "bxas vykb okgh anyh";
            string emailTo = "derblaysbonates@gmail.com ";
           // string emailTo = "miguelkedroon@gmail.com";
            string subject = "Celestial Planetarium";
            //string body = System.IO.File.ReadAllText(@"EmailTemplate\index.htm").Replace("#titulodoemail","Email de teste").Replace("#corpodoemail","Conteudo muito doido, uehueheuehuehue");
 
            using (MailMessage mail = new MailMessage())
            {

                mail.From = new MailAddress(emailFrom);
                mail.To.Add(emailTo);
                mail.Subject = subject;
                //mail.Body = body;
                mail.IsBodyHtml = true;
                mail.AlternateViews.Add(getEmbeddedImage("hondatrading.jpg"));

                // Can set to false, if you are sending pure text.


                using (SmtpClient smtp = new SmtpClient(smtpAddress, portNumber))
                {
                    smtp.Credentials = new NetworkCredential(emailFrom, password);
                    smtp.EnableSsl = enableSSL;
                    
                    smtp.Send(mail);
                }
            }
        }
        private static AlternateView getEmbeddedImage(string filePath)
        {
            LinkedResource inline = new LinkedResource(filePath);
            inline.ContentId = Guid.NewGuid().ToString();
            string htmlBody = System.IO.File.ReadAllText(@"EmailTemplate\index.htm").Replace("#titulodoemail", "Algalon the Observer").Replace("#corpodoemail", @"I have seen worlds bathed in the Makers' flames. Their denizens fading without so much as a whimper. Entire planetary systems born and raised in the time that it takes your mortal hearts to beat once. Yet all throughout, my own heart, devoid of emotion... of empathy. I... have... felt... NOTHING! A million, million lives wasted. Had they all held within them your tenacity? Had they all loved life as you do?
Perhaps it is your imperfection that which grants you free will.That allows you to persevere against cosmically calculated odds.You prevailed where the Titans' own perfect creations have failed.").Replace("src=#teste", "src='cid:" + inline.ContentId + @"'");
            //string htmlBody = @"<img src='cid:" + inline.ContentId + @"'/>";
            AlternateView alternateView = AlternateView.CreateAlternateViewFromString(htmlBody, null, MediaTypeNames.Text.Html);
            alternateView.LinkedResources.Add(inline);
            return alternateView;
        }
    }
}
